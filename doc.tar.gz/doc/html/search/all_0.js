var searchData=
[
  ['_5f_5fstdc_5fformat_5fmacros',['__STDC_FORMAT_MACROS',['../global_8h.html#aacbb9e1f38be71e22df1584a37c56693',1,'global.h']]],
  ['_5fmy_5f_5fglobal_5f_5fh',['_MY__GLOBAL__H',['../global_8h.html#aa9c3c084d352d93ad2031d3214e9cd10',1,'global.h']]]
];
