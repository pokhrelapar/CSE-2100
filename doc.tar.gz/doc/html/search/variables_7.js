var searchData=
[
  ['ser_5fdev',['ser_dev',['../global_8cpp.html#ae6d733e6d4da52ea2dae8e56b000e5de',1,'ser_dev():&#160;global.cpp'],['../global_8h.html#ae6d733e6d4da52ea2dae8e56b000e5de',1,'ser_dev():&#160;global.cpp']]]
];
