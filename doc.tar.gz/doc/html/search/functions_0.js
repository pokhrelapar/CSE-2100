var searchData=
[
  ['button_5fclosedevice_5fclicked',['button_closedevice_clicked',['../main_8cpp.html#ad3cf8a83b5ee3d3d19ed77fe61a7497d',1,'main.cpp']]],
  ['button_5fexit_5fclicked',['button_exit_clicked',['../main_8cpp.html#a133607be026e45cbd298bb6644ac5bc4',1,'main.cpp']]],
  ['button_5fopendevice_5fclicked',['button_opendevice_clicked',['../main_8cpp.html#a6476bac2120be7b53beae69b27b392bc',1,'main.cpp']]],
  ['button_5fsend_5fclicked',['button_send_clicked',['../main_8cpp.html#aea199709c0a72e65d41b5e2cb32e65de',1,'main.cpp']]]
];
