var searchData=
[
  ['max_5fadc_5fvalue',['MAX_ADC_VALUE',['../serialreadthread_8cpp.html#a91f5af028cd707fcddafff4416925b21',1,'serialreadthread.cpp']]],
  ['max_5fvoltage',['MAX_VOLTAGE',['../serialreadthread_8cpp.html#a0637861f9419cef73e2e7e6210280e4e',1,'serialreadthread.cpp']]]
];
