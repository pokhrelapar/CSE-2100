var searchData=
[
  ['c_5fvoltage_5fvalue',['c_voltage_value',['../global_8cpp.html#aed7ab25953a9c22e02e6986f24a8bed2',1,'c_voltage_value():&#160;global.cpp'],['../global_8h.html#aed7ab25953a9c22e02e6986f24a8bed2',1,'c_voltage_value():&#160;global.cpp']]]
];
